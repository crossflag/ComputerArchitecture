Names: Dalton Melville, Diego Santana
how to run program
python team12_Project2.py -i filename -o filename
EX: python team12_Project2.py -i test.txt -o team12